# Pizza-App
Name: Dishan Gohel
Student I.D: 101254621

Description!
PiCo is a pizza company where you can craft your pizza.
Select your choice of Sauce,Cheese and Proteins.
It allows user to create a custom pizza.

Setup/Requirements.
This program can be edited/accessed on a computer with Visual Studio code or Atom and Git Installed.
1.Clone this Repository
2.Open Index.html

Known Bugs.
As you customize your pizza and click Place Order button or Checkout button there is no output.
Still a beginner in JavaScript. Will solve the issue as soon as possible.

Specifications.
This web app calculates the price of the selected customized pizza based on the form.

Future Features.
Make the page responsive.
Add high resolutions pictures of food.

Technologies Used.
1. HTML
2.CSS
3.Javascript

Links.
Git Hub Web Page: https://dishan16.github.io/Pizza-App/
